.. _changelog:

Changelog
=========

`Version 0.1 (2018 Feb 07)`
----------------------------
- Made it compatible with Odoo 14 community and Enterprise editions

